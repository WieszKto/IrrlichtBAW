License for Ditt Office Scene
Copyright 2017 Ditt B.V. All rights reserved.


Redistribution and use of this scene description, with or without modification, are permitted provided that the following conditions are met:

1. The scene description or any part of it may only be used for research or software development (including benchmarking) purposes.
2. Redistributions of this scene description or any part of it must include the above copyright notice, this list of conditions and the following disclaimer.
3. The names �Ditt�, �DevSH Graphics Programming�, �DevSH� or the names of its contributors may NOT be used to promote or to imply endorsement, sponsorship, or affiliation with products developed or tested utilizing this scene description or benchmarking results obtained from this scene description, without prior written permission from Ditt B.V. and DevSH Graphics Programming Sp. z O.O.

THIS SCENE DESCRIPTION IS PROVIDED BY DEVSH GRAPHICS PROGRAMMING �AS IS� AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL WALT DISNEY PICTURES BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SCENE DESCRIPTION, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.